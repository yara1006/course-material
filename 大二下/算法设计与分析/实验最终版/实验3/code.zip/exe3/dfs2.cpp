//最大度优化
#include <iostream>
#include <cstring>
#include <vector>
#include <chrono>
using namespace std;
using namespace std::chrono;
const int N =10;   //最大节点
vector<int>adj[N]; //邻接表
int color[N]; 
int MAXC=4;   //可填颜色数
int cnt=0;
bool vis[N];//是否已经染色

bool isSafe(int node ,int c){ //能否填色
    for(int nei:adj[node]){
        if(color[nei]==c) return false;
    }
    return true;
}
//选择当前还没有染色的最大度节点
int selectMaxDegree(int n){
    int maxDeg=-1;
    int selected=-1;
    for(int i=1;i<=n;i++){
        if(!vis[i]){
            int deg=0;
            for(int nei:adj[i]){
                if(!vis[nei]) deg++;
            }
            if(deg>maxDeg){
                maxDeg=deg;
                selected=i;
            }
        }
    }
    return selected;
}
void colorGraph(int n ,int depth=0){
    if(depth==n){
        cnt++;
        return ;
    }
    int node=selectMaxDegree(n);
    if(node==-1) return;

    vis[node]=true;

    
    for(int c=1;c<=MAXC;c++){
        if(isSafe(node,c)){
            color[node]=c;
            colorGraph(n,depth+1);//递归搜索下一个节点
            color[node]=0; 
        }
    }
    vis[node]=false;//回溯
}
void init(){
    //小规模地图数据验证
    
    adj[1]={2,3,4};
    adj[2]={1,3,4,5};
    adj[3]={1,2,4};
    adj[4]={1,2,3,5,6,7};
    adj[5]={2,4,6,9};
    adj[6]={4,5,7,8,9};
    adj[7]={4,6,8};
    adj[8]={6,7,9};
    adj[9]={5,6,8};
    memset(vis, 0, sizeof(vis));
    memset(color, 0, sizeof(color));
}
int main()
{
    init();
    int n=9;
    //执行回溯图着色
    auto start=steady_clock::now();
    colorGraph(n);
    auto end=steady_clock::now();
    auto duration=duration_cast<microseconds>(end-start).count();
    
    cout<<"总共找到："<<cnt<<"种合法着色方案"<<endl;
    cout<<"耗时："<<duration<<"微秒"<<endl;

    return 0;
}