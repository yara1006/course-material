//普通回溯法
#include <iostream>
#include <cstring>
#include <vector>
#include <chrono>
using namespace std;
using namespace std::chrono;
const int N =10;   //最大节点
vector<int>adj[N]; //邻接表
int color[N]; 
int MAXC=4;   //可填颜色数
int cnt=0;

bool isSafe(int node ,int c){ //能否填色
    for(int nei:adj[node]){
        if(color[nei]==c) return false;
    }
    return true;
}

void colorGraph(int node ,int n){
    if(node>n){
        cnt++;
        return ;
    }
    for(int c=1;c<=MAXC;c++){
        if(isSafe(node,c)){
            color[node]=c;
            colorGraph(node+1,n);//递归搜索下一个节点
            color[node]=0; //回溯
        }
    }
}

int main()
{
    //小规模地图数据验证
    int n=9;
    adj[1]={2,3,4};
    adj[2]={1,3,4,5};
    adj[3]={1,2,4};
    adj[4]={1,2,3,5,6,7};
    adj[5]={2,4,6,9};
    adj[6]={4,5,7,8,9};
    adj[7]={4,6,8};
    adj[8]={6,7,9};
    adj[9]={5,6,8};
 
    //执行回溯图着色
    auto start=steady_clock::now();
    colorGraph(1,n);
    auto end=steady_clock::now();
    auto duration=duration_cast<microseconds>(end-start).count();
    
    cout<<"总共找到："<<cnt<<"种合法着色方案"<<endl;
    cout<<"耗时："<<duration<<"微秒"<<endl;

    return 0;
}