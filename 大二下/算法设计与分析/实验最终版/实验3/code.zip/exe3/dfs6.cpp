#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e3 + 10;
const int MAXCOL = 4;  // 最大颜色数

int n, m;
int color[MAXN];                  // 每个节点的颜色
int link[MAXN][MAXN];             // 邻接矩阵
int deg[MAXN];                    // 每个点的度数
vector<int> vmatrix[MAXN];        // 邻接表

int state[MAXN], siz[MAXN];       // 每个点的状态（颜色掩码）和剩余颜色数量
bool colored[MAXN][MAXN];         // 标记染色的邻接节点

// 检查当前染色是否合法
bool Check() {
    for (int i = 1; i <= n; i++) {
        if (color[i] == 0) {
            return false;
        }
        for (int k = 0; k < vmatrix[i].size(); k++) {
            int j = vmatrix[i][k];
            if (link[i][j] && color[i] == color[j]) {
                return false;
            }
        }
    }
    return true;
}

// 更新邻居的颜色状态
bool UpdateColor(int u, int col) {
    int limit = (1 << (col - 1));
    for (int k = 0; k < vmatrix[u].size(); k++) {
        int j = vmatrix[u][k];
        if (link[u][j]) {
            if (!color[j] && (state[j] & limit)) {
                colored[u][j] = true;
                state[j] ^= limit;
                siz[j]--;
                if (siz[j] == 0) {
                    return false;  // 出现无可用颜色，提前剪枝
                }
            }
        }
    }
    return true;
}

// 恢复邻居的颜色状态
void RecoveryColor(int u, int col) {
    int limit = (1 << (col - 1));
    for (int k = 0; k < vmatrix[u].size(); k++) {
        int j = vmatrix[u][k];
        if (colored[u][j]) {
            colored[u][j] = false;
            state[j] |= limit;
            siz[j]++;
        }
    }
}

// 深搜 + 最少颜色优先 + 最大度优先 + 提前中断
long long DFS6(int x) {
    if (x > n) {
        if (!Check()) return 0;
        return 1;
    }
    int u = 0;
    for (int i = 1; i <= n; i++) {
        if (!color[i]) {
            if (siz[i] < siz[u] || (siz[i] == siz[u] && deg[i] > deg[u])) {
                u = i;
            }
        }
    }
    long long cnt = 0;
    for (int i = 1; i <= MAXCOL; i++) {
        if (state[u] & (1 << (i - 1))) {
            color[u] = i;
            bool flag = true;
            int limit = 1 << (i - 1);
            for (int k = 0; k < vmatrix[u].size(); k++) {
                int j = vmatrix[u][k];
                if (link[u][j] && !color[j] && (state[j] & limit)) {
                    colored[u][j] = true;
                    state[j] ^= limit;
                    siz[j]--;
                    if (siz[j] == 0) {
                        flag = false;
                        break;
                    }
                }
            }
            if (flag) {
                cnt += DFS6(x + 1);
            }
            // 回溯
            color[u] = 0;
            for (int j = 1; j <= n; j++) {
                if (colored[u][j]) {
                    colored[u][j] = false;
                    state[j] |= limit;
                    siz[j]++;
                }
            }
        }
    }
    return cnt;
}

// 主函数：最少颜色 + 最大度 + 提前中断 + 对称性去重
long long SolveWithSymmetry(int start_node) {
    memset(color, 0, sizeof(color));
    memset(state, -1, sizeof(state));
    memset(colored, false, sizeof(colored));
    for (int i = 1; i <= n; i++) siz[i] = MAXCOL;
    siz[0] = 100;

    long long ans = 0;
    if (n == 1) {
        ans = MAXCOL;
    } else if (n == 2) {
        ans = MAXCOL * (MAXCOL - 1);
    } else {
        color[start_node] = 1;
        UpdateColor(start_node, 1);
        int u = 0;
        for (int i = 1; i <= n; i++)
            if (link[start_node][i] && deg[u] < deg[i]) u = i;
        color[u] = 2;
        UpdateColor(u, 2);
        int v = 0;
        for (int i = 1; i <= n; i++)
            if (link[u][i] && link[start_node][i] && deg[v] < deg[i]) v = i;
        if (v == 0) {
            for (int i = 1; i <= n; i++)
                if (i != start_node && i != u && (link[i][u] || link[i][start_node]) && deg[v] < deg[i]) v = i;
            color[v] = 3;
            UpdateColor(v, 3);
            ans = MAXCOL * (MAXCOL - 1) * (MAXCOL - 2) * DFS6(4);
            RecoveryColor(v, 3);
            color[v] = 1;
            UpdateColor(v, 1);
            ans += MAXCOL * (MAXCOL - 1) * DFS6(4);
        } else {
            color[v] = 3;
            UpdateColor(v, 3);
            ans = MAXCOL * (MAXCOL - 1) * (MAXCOL - 2) * DFS6(4);
        }
    }
    return ans;
}

int main() {
    //printf("请输入图的节点数 n 和边数 m:\n");
    scanf("p edge %d %d%*c", &n, &m);
    //printf("请输入每条边 (格式: u v):\n");
    for (int i = 0; i < m; ++i) {
        int u, v;
        scanf("e %d %d%*c", &u, &v);
        link[u][v] = link[v][u] = 1;
        deg[u]++;
        deg[v]++;
        vmatrix[u].push_back(v);
        vmatrix[v].push_back(u);
    }

    //printf("开始计算（最少颜色 + 最大度 + 提前中断 + 对称性去重优化）...\n");
    auto start = clock();
    long long totalWays = SolveWithSymmetry(1);
    auto end = clock();

    printf("合法着色方案数量: %lld\n", totalWays);
    printf("耗时: %d ms\n", (int)(end - start));
    return 0;
}
