#include <iostream>
#include <vector>
#include <chrono>
#include <algorithm>
#include <fstream>
#include <sstream>
using namespace std;
using namespace std::chrono;
#include <iomanip>  
const int MAXN=500;//最大点数

int matrix[MAXN][MAXN];//邻接矩阵
vector<int> adj[MAXN]; //邻接表
int main()
{
    int n=0,m=0;
    vector<pair<int,int>>edges;
    //读取.col文件
    ifstream infile("le450_25a.col");
    if (!infile.is_open()) {
        cerr << "文件打开失败，请检查路径是否正确！" << endl;
        return 1;
    }
    string line;
    while(getline(infile,line)){
        if(line[0]=='p'){
            stringstream ss(line);
            string p,edge;
            ss>>p>>edge>>n>>m;
        }else if(line[0]=='e'){
            int u,v;
            sscanf(line.c_str(),"e %d %d",&u,&v);
            u--;v--;
            edges.emplace_back(u,v);

            matrix[u][v]=matrix[v][u]=1;
            adj[u].push_back(v);
            adj[v].push_back(u);
        }
    }
    infile.close();

    const int T = 1000; // 重复次数
    int cnt_list = 0, cnt_matrix = 0;
    
    // 邻接矩阵
    auto start_matrix = high_resolution_clock::now();
    for (int t = 0; t < T; ++t) {
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < n; ++j)
                if (matrix[i][j])
                    cnt_matrix++;
    }
    auto end_matrix = high_resolution_clock::now();
    double time_matrix = duration<double>(end_matrix - start_matrix).count() / T;
    
    // 邻接表
    auto start_list = high_resolution_clock::now();
    for (int t = 0; t < T; ++t) {
        for (int i = 0; i < n; ++i)
            for (int v : adj[i])
                cnt_list++;
    }
    auto end_list = high_resolution_clock::now();
    double time_list = duration<double>(end_list - start_list).count() / T;

    
    cout << fixed << setprecision(6);  // 设置统一小数位数（6位）
    // 除以 T 后的真实结果（单位：秒）
    cout << "邻接矩阵遍历平均耗时: " << time_matrix << " 秒，访问总数: " << cnt_matrix / T << endl;
    cout << "邻接表遍历平均耗时: " << time_list << " 秒，访问总数: " << cnt_list /T << endl;
    

    return 0;
}