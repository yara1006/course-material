//最大度+最少颜色优化
#include <iostream>
#include <vector>
#include <cstring>
#include <chrono>
using namespace std;
using namespace chrono;

const int MAX_NODE = 1e3 + 10;
const int MAX_COLOR = 4;

int n, m;
int nodeColors[MAX_NODE];              // 存储每个节点的颜色
int adjacency[MAX_NODE][MAX_NODE];     // 邻接矩阵
int degrees[MAX_NODE];                 // 节点度数
vector<int> neighbors[MAX_NODE];       // 邻接表

int colorMask[MAX_NODE], optionsLeft[MAX_NODE]; 
bool updatedFlag[MAX_NODE][MAX_NODE];  // 标记相邻节点的状态

// 校验当前染色是否满足要求
bool isValid() {
    for (int u = 1; u <= n; ++u) {
        if (nodeColors[u] == 0) return false;  // 有未染色的节点
        for (int v : neighbors[u]) {
            if (adjacency[u][v] && nodeColors[u] == nodeColors[v]) {
                return false;  // 相邻节点颜色冲突
            }
        }
    }
    return true;
}

// 回溯 + 最少颜色优先 + 最大度优先
int colorDFS(int depth) {
    if (depth > n) {
        return isValid() ? 1 : 0;
    }

    int target = 0;
    for (int i = 1; i <= n; ++i) {
        if (!nodeColors[i]) {
            if (optionsLeft[i] < optionsLeft[target] ||
                (optionsLeft[i] == optionsLeft[target] && degrees[i] > degrees[target])) {
                target = i;
            }
        }
    }

    int ways = 0;
    for (int c = 1; c <= MAX_COLOR; ++c) {
        if (colorMask[target] & (1 << (c - 1))) {
            nodeColors[target] = c;
            int bit = (1 << (c - 1));
            for (int v : neighbors[target]) {
                if (adjacency[target][v] && !nodeColors[v] && (colorMask[v] & bit)) {
                    updatedFlag[target][v] = true;
                    colorMask[v] ^= bit;
                    optionsLeft[v]--;
                }
            }
            ways += colorDFS(depth + 1);
            // 回溯还原
            nodeColors[target] = 0;
            for (int v = 1; v <= n; ++v) {
                if (updatedFlag[target][v]) {
                    updatedFlag[target][v] = false;
                    colorMask[v] |= bit;
                    optionsLeft[v]++;
                }
            }
        }
    }
    return ways;
}

int solveColoring() {
    memset(nodeColors, 0, sizeof(nodeColors));
    memset(colorMask, -1, sizeof(colorMask)); // 初始化为全1，表示所有颜色可用
    memset(updatedFlag, 0, sizeof(updatedFlag));
    for (int i = 1; i <= n; ++i) optionsLeft[i] = MAX_COLOR;
    optionsLeft[0] = 9999; // 确保初始比较不会选中
    return colorDFS(1);
}

int main() {
    //cout << "输入节点数 n 和边数 m:" << endl;
    scanf("p edge %d %d%*c", &n, &m);
    cout << "输入边的信息 (格式: u v):" << endl;
    for (int i = 0; i < m; ++i) {
        int u, v;
        //cin >> u >> v;
        scanf("e %d %d%*c", &u, &v);
        adjacency[u][v] = adjacency[v][u] = 1;
        degrees[u]++;
        degrees[v]++;
        neighbors[u].push_back(v);
        neighbors[v].push_back(u);
    }

    auto startTime = steady_clock::now();
    int totalSolutions = solveColoring();
    auto endTime = steady_clock::now();
    auto elapsed = duration_cast<milliseconds>(endTime - startTime).count();

    cout << "找到的合法着色方案数: " << totalSolutions << endl;
    cout << "执行耗时: " << elapsed << " 毫秒" << endl;
    return 0;
}
