//最大度+最少颜色+提前中断
#include <iostream>
#include <vector>
#include <cstring>
#include <chrono>
using namespace std;
using namespace chrono;

const int MAXN = 1005;
const int MAX_COLOR = 4;

int totalNodes, totalEdges;
int currentColor[MAXN];                   // 节点颜色数组
int adjMatrix[MAXN][MAXN];                // 邻接矩阵
int nodeDegree[MAXN];                     // 记录每个节点的度数
vector<int> adjList[MAXN];                // 邻接表

int colorStatus[MAXN], availableColors[MAXN]; 
bool stateFlag[MAXN][MAXN];               // 标记节点状态更新

// 检查当前染色是否合法
bool isSolutionValid() {
    for (int u = 1; u <= totalNodes; ++u) {
        if (currentColor[u] == 0) return false;
        for (int v : adjList[u]) {
            if (adjMatrix[u][v] && currentColor[u] == currentColor[v]) {
                return false;
            }
        }
    }
    return true;
}

// DFS + MRV + 最大度 + 提前剪枝
bool dfsBacktrack(int step) {
    if (step > totalNodes) {
        return true;
    }

    int selectNode = 0;
    for (int i = 1; i <= totalNodes; ++i) {
        if (!currentColor[i]) {
            if (availableColors[i] < availableColors[selectNode] ||
                (availableColors[i] == availableColors[selectNode] && nodeDegree[i] > nodeDegree[selectNode])) {
                selectNode = i;
            }
        }
    }

    if (availableColors[selectNode] == 0) {
        // 已经无可用颜色，提前中断
        return false;
    }

    for (int color = 1; color <= MAX_COLOR; ++color) {
        if (colorStatus[selectNode] & (1 << (color - 1))) {
            currentColor[selectNode] = color;
            int bitMask = 1 << (color - 1);
            vector<int> affected;

            for (int neighbor : adjList[selectNode]) {
                if (adjMatrix[selectNode][neighbor] && !currentColor[neighbor] && (colorStatus[neighbor] & bitMask)) {
                    stateFlag[selectNode][neighbor] = true;
                    colorStatus[neighbor] ^= bitMask;
                    availableColors[neighbor]--;
                    affected.push_back(neighbor);
                }
            }

            if (dfsBacktrack(step + 1)) {
                return true;  // 找到一种可行解，提前返回
            }

            // 回溯还原
            currentColor[selectNode] = 0;
            for (int neighbor : affected) {
                stateFlag[selectNode][neighbor] = false;
                colorStatus[neighbor] |= bitMask;
                availableColors[neighbor]++;
            }
        }
    }
    return false;  // 当前路径未找到解
}

// 启动函数
bool solveColoring() {
    memset(currentColor, 0, sizeof(currentColor));
    memset(colorStatus, -1, sizeof(colorStatus));  // 所有颜色初始可用
    memset(stateFlag, 0, sizeof(stateFlag));
    for (int i = 1; i <= totalNodes; ++i) availableColors[i] = MAX_COLOR;
    availableColors[0] = 1e9;  // 防止选到 0 号节点
    return dfsBacktrack(1);
}

int main() {
    //cout << "请输入节点数 和 边数:" << endl;
    //cin >> totalNodes >> totalEdges;
    //cout << "请输入边（格式：u v）:" << endl;
    scanf("p edge %d %d%*c", &totalNodes , &totalEdges);
    for (int i = 0; i < totalEdges; ++i) {
        int u, v;
        //cin >> u >> v;
        scanf("e %d %d%*c", &u, &v);
        adjMatrix[u][v] = adjMatrix[v][u] = 1;
        nodeDegree[u]++;
        nodeDegree[v]++;
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }

    auto startTime = steady_clock::now();
    bool hasSolution = solveColoring();
    auto endTime = steady_clock::now();
    auto usedTime = duration_cast<milliseconds>(endTime - startTime).count();

    if (hasSolution) {
        cout << "找到至少一种可行的合法着色方案。" << endl;
    } else {
        cout << "没有找到可行的着色方案。" << endl;
    }
    cout << "搜索耗时: " << usedTime << " 毫秒" << endl;
    return 0;
}
