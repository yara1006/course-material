//最少颜色优化
#include <iostream>
#include <vector>
#include <cstring>
#include <chrono>
using namespace std;
using namespace chrono;

const int NODE_MAX = 1e3 + 10;
const int COLOR_LIMIT = 4;

int nodeColor[NODE_MAX];               // 每个节点的当前颜色
int availableColorMask[NODE_MAX];      // 每个节点的可用颜色掩码
int availableCount[NODE_MAX];          // 每个节点剩余可用颜色数
bool updated[NODE_MAX][NODE_MAX];      // 标记哪些相邻点已更新过
int totalNodes = 9;                    // 节点数
vector<int> adjacencyList[NODE_MAX];   // 邻接表

// 初始化图结构
void initGraph() {
    adjacencyList[1] = {2, 3, 4};
    adjacencyList[2] = {1, 3, 4, 5};
    adjacencyList[3] = {1, 2, 4};
    adjacencyList[4] = {1, 2, 3, 5, 6, 7};
    adjacencyList[5] = {2, 4, 6, 9};
    adjacencyList[6] = {4, 5, 7, 8, 9};
    adjacencyList[7] = {4, 6, 8};
    adjacencyList[8] = {6, 7, 9};
    adjacencyList[9] = {5, 6, 8};
}

// 校验当前染色是否合法
bool validateColoring() {
    for (int i = 1; i <= totalNodes; i++) {
        if (nodeColor[i] == 0) return false; // 未染色
        for (int neighbor : adjacencyList[i]) {
            if (nodeColor[i] == nodeColor[neighbor]) return false; // 相邻同色
        }
    }
    return true;
}

// 使用最少剩余颜色优先的深搜
int optimizedDFS(int depth) {
    if (depth > totalNodes) {
        return validateColoring() ? 1 : 0;
    }

    int nextNode = 0;
    for (int i = 1; i <= totalNodes; i++) {
        if (nodeColor[i] == 0 && availableCount[i] < availableCount[nextNode]) {
            nextNode = i;
        }
    }

    int solutions = 0;
    for (int color = 1; color <= COLOR_LIMIT; color++) {
        if (availableColorMask[nextNode] & (1 << (color - 1))) {
            nodeColor[nextNode] = color;
            int colorBit = (1 << (color - 1));
            vector<int> affectedNodes;

            for (int neighbor : adjacencyList[nextNode]) {
                if (!nodeColor[neighbor] && (availableColorMask[neighbor] & colorBit)) {
                    updated[nextNode][neighbor] = true;
                    availableColorMask[neighbor] ^= colorBit;
                    availableCount[neighbor]--;
                    affectedNodes.push_back(neighbor);
                }
            }

            solutions += optimizedDFS(depth + 1);

            // 回溯复原
            nodeColor[nextNode] = 0;
            for (int neighbor : affectedNodes) {
                updated[nextNode][neighbor] = false;
                availableColorMask[neighbor] |= colorBit;
                availableCount[neighbor]++;
            }
        }
    }
    return solutions;
}

// 初始化并启动搜索
int runSolver() {
    memset(nodeColor, 0, sizeof(nodeColor));
    memset(availableColorMask, -1, sizeof(availableColorMask));
    memset(updated, false, sizeof(updated));
    for (int i = 1; i <= totalNodes; i++) availableCount[i] = COLOR_LIMIT;
    availableCount[0] = 1e9;  // 给 dummy 节点一个很大值
    return optimizedDFS(1);
}

int main() {
    initGraph();
    auto start = steady_clock::now();
    int totalWays = runSolver();
    auto end = steady_clock::now();
    auto timeCost = duration_cast<microseconds>(end - start).count();
    cout << "总共找到的可行方案数: " << totalWays << endl;
    cout << "耗时: " << timeCost << " 微秒" << endl;
    return 0;
}
