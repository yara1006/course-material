#include <iostream>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <cstring>

using namespace std;

const int MAX_COORD = 1e5;
const double EPSILON = 1e-8;

struct Vec2 {
    double x, y;
    Vec2(double x_=0, double y_=0) : x(x_), y(y_) {}
    Vec2 operator-(const Vec2 &o) const { return Vec2(x - o.x, y - o.y); }
};

class Edge {
public:
    Vec2 p1, p2;
    Edge(Vec2 a, Vec2 b) : p1(a), p2(b) {}
};

class GeometryUtils {
public:
    static int sign(double val) {
        if (val < -EPSILON) return -1;
        if (val > EPSILON) return 1;
        return 0;
    }

    // 计算叉积
    static double cross(const Vec2 &a, const Vec2 &b) {
        return a.x * b.y - a.y * b.x;
    }

    static double cross(const Vec2 &base, const Vec2 &a, const Vec2 &b) {
        return cross(a - base, b - base);
    }

    // 计算点积
    static double dot(const Vec2 &a, const Vec2 &b) {
        return a.x * b.x + a.y * b.y;
    }

    static double dot(const Vec2 &base, const Vec2 &a, const Vec2 &b) {
        return dot(a - base, b - base);
    }

    // 判断是否有交点
    static bool isIntersect(const Edge &e1, const Edge &e2) {
        int c1 = sign(cross(e1.p1, e1.p2, e2.p1));
        int c2 = sign(cross(e1.p1, e1.p2, e2.p2));
        int c3 = sign(cross(e2.p1, e2.p2, e1.p1));
        int c4 = sign(cross(e2.p1, e2.p2, e1.p2));

        // 判断是否严格相交
        if ((c1 ^ c2) == -2 && (c3 ^ c4) == -2)
            return true;

        // 判断是否共线且重叠
        if ((c1 == 0 && sign(dot(e2.p1 - e1.p1, e2.p1 - e1.p2)) <= 0) ||
            (c2 == 0 && sign(dot(e2.p2 - e1.p1, e2.p2 - e1.p2)) <= 0) ||
            (c3 == 0 && sign(dot(e1.p1 - e2.p1, e1.p1 - e2.p2)) <= 0) ||
            (c4 == 0 && sign(dot(e1.p2 - e2.p1, e1.p2 - e2.p2)) <= 0))
            return true;

        return false;
    }
};

class RandomGraphGenerator {
    int numPoints, numEdges;
    vector<Vec2> nodes;
    vector<Edge> edges;
    bool hasEdge[10010][10010];

public:
    RandomGraphGenerator(int n, int m) : numPoints(n), numEdges(m) {
        memset(hasEdge, 0, sizeof(hasEdge));
        srand((unsigned)time(0));
    }

    void generatePoints() {
        nodes.resize(numPoints + 1);
        for (int i = 1; i <= numPoints; ++i) {
            nodes[i].x = rand() % MAX_COORD;
            nodes[i].y = rand() % MAX_COORD;
        }
    }

    void generateEdges() {
        cout << "p edge " << numPoints << " " << numEdges << endl;
        int attempts = 0;
        while ((int)edges.size() < numEdges) {
            int u = rand() % numPoints + 1;
            int v = rand() % numPoints + 1;
            if (u == v || hasEdge[u][v]) continue;

            Edge candidate(nodes[u], nodes[v]);
            bool valid = true;
            for (const auto &existing : edges) {
                if (GeometryUtils::isIntersect(existing, candidate)) {
                    valid = false;
                    break;
                }
            }

            if (valid) {
                edges.push_back(candidate);
                hasEdge[u][v] = hasEdge[v][u] = true;
                cout << "e " << u << " " << v << endl;
            }

            // 安全机制，避免死循环
            if (++attempts > numEdges * 100) break;
        }
    }
};

int main() {
    int pointCount = 10, edgeCount = 20;
    RandomGraphGenerator generator(pointCount, edgeCount);
    generator.generatePoints();
    generator.generateEdges();
    return 0;
}
