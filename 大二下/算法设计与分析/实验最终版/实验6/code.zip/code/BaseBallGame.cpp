#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <unordered_map>
#include <queue>
#include <stack>
#include <algorithm>
#include <cmath>
#include <limits>
#include <memory>
#include <chrono>

using namespace std;

// 浮点数精度常量，用于比较double类型的数值
const double FLOATING_POINT_EPSILON = 1E-11;

// C++11兼容的make_unique实现，方便智能指针的创建
// 用于动态分配对象并返回unique_ptr
// 例如：auto ptr = make_unique<MyClass>(参数...);
template<typename T, typename... Args>
unique_ptr<T> make_unique(Args&&... args) {
    return unique_ptr<T>(new T(forward<Args>(args)...));
}

// ================== 最大流相关类声明 ==================
class FlowEdge;
class FlowNetwork;
class FF;

// ================== 流边类 ==================
// 表示流网络中的一条边，包含起点、终点、容量和当前流量
class FlowEdge {
private:
    int v;              // 边的起点
    int w;              // 边的终点
    double capacity;    // 边的容量
    double flow;        // 当前流量

public:
    // 构造函数，初始化边的起点、终点和容量，初始流量为0
    FlowEdge(int v, int w, double capacity) : v(v), w(w), capacity(capacity), flow(0.0) {
        if (v < 0) throw invalid_argument("vertex index must be a non-negative integer");
        if (w < 0) throw invalid_argument("vertex index must be a non-negative integer");
        if (capacity < 0.0) throw invalid_argument("Edge capacity must be non-negative");
    }

    // 构造函数，初始化边的起点、终点、容量和流量
    FlowEdge(int v, int w, double capacity, double flow) : v(v), w(w), capacity(capacity), flow(flow) {
        if (v < 0) throw invalid_argument("vertex index must be a non-negative integer");
        if (w < 0) throw invalid_argument("vertex index must be a non-negative integer");
        if (capacity < 0.0) throw invalid_argument("edge capacity must be non-negative");
        if (flow > capacity) throw invalid_argument("flow exceeds capacity");
        if (flow < 0.0) throw invalid_argument("flow must be non-negative");
    }

    // 获取起点
    int from() const { return v; }
    // 获取终点
    int to() const { return w; }
    // 获取容量
    double getCapacity() const { return capacity; }
    // 获取当前流量
    double getFlow() const { return flow; }

    // 获取与vertex相对的另一个端点
    int other(int vertex) const {
        if (vertex == v) return w;
        else if (vertex == w) return v;
        else throw invalid_argument("invalid endpoint");
    }

    // 获取vertex方向上的剩余容量
    double residualCapacityTo(int vertex) const {
        if (vertex == v) return flow;              // 反向边
        else if (vertex == w) return capacity - flow;   // 正向边
        else throw invalid_argument("invalid endpoint");
    }

    // 向vertex方向增加delta流量
    void addResidualFlowTo(int vertex, double delta) {
        if (delta < 0.0) throw invalid_argument("Delta must be nonnegative");

        if (vertex == v) flow -= delta;           // 反向边
        else if (vertex == w) flow += delta;      // 正向边
        else throw invalid_argument("invalid endpoint");

        // 处理浮点误差
        if (abs(flow) <= FLOATING_POINT_EPSILON)
            flow = 0;
        if (abs(flow - capacity) <= FLOATING_POINT_EPSILON)
            flow = capacity;

        if (flow < 0.0) throw invalid_argument("Flow is negative");
        if (flow > capacity) throw invalid_argument("Flow exceeds capacity");
    }

    // 边的信息字符串表示
    string toString() const {
        return to_string(v) + "->" + to_string(w) + " " + to_string(flow) + "/" + to_string(capacity);
    }
};

// ================== 流网络类 ==================
// 表示一个有向流网络，包含顶点、边和邻接表
class FlowNetwork {
private:
    int V;    // 顶点数
    int E;    // 边数
    vector<vector<shared_ptr<FlowEdge>>> adj; // 邻接表

public:
    // 构造函数，初始化V个顶点
    FlowNetwork(int V) : V(V), E(0) {
        if (V < 0) throw invalid_argument("Number of vertices in a Graph must be nonnegative");
        adj.resize(V);
    }

    // 获取顶点数
    int getV() const { return V; }
    // 获取边数
    int getE() const { return E; }

    // 检查顶点编号是否合法
    void validateVertex(int v) const {
        if (v < 0 || v >= V)
            throw invalid_argument("vertex " + to_string(v) + " is not between 0 and " + to_string(V-1));
    }

    // 添加一条边到网络
    void addEdge(shared_ptr<FlowEdge> e) {
        int v = e->from();
        int w = e->to();
        validateVertex(v);
        validateVertex(w);
        adj[v].push_back(e);
        adj[w].push_back(e);
        E++;
    }

    // 获取与顶点v相连的所有边
    const vector<shared_ptr<FlowEdge>>& getAdj(int v) const {
        validateVertex(v);
        return adj[v];
    }

    // 获取所有边（去重）
    vector<shared_ptr<FlowEdge>> edges() const {
        vector<shared_ptr<FlowEdge>> list;
        for (int v = 0; v < V; v++) {
            for (const auto& e : adj[v]) {
                if (e->to() != v)
                    list.push_back(e);
            }
        }
        return list;
    }

    // 网络信息字符串表示
    string toString() const {
        string s = to_string(V) + " " + to_string(E) + "\n";
        for (int v = 0; v < V; v++) {
            s += to_string(v) + ":  ";
            for (const auto& e : adj[v]) {
                if (e->to() != v) s += e->toString() + "  ";
            }
            s += "\n";
        }
        return s;
    }
};

// ================== Ford-Fulkerson 最大流算法类 ==================
// 用于计算流网络中的最大流
class FF {
private:
    int V;    // 顶点数
    vector<bool> marked; // 标记数组，记录增广路径
    vector<shared_ptr<FlowEdge>> edgeTo; // 路径上的边
    double value; // 最大流值

    // 寻找增广路径，DFS实现
    bool hasAugmentingPath(const FlowNetwork& G, int s, int t) {
        edgeTo.resize(G.getV());
        marked.assign(G.getV(), false);

        stack<int> st;
        st.push(s);
        marked[s] = true;

        while (!st.empty() && !marked[t]) {
            int v = st.top();
            st.pop();

            for (const auto& e : G.getAdj(v)) {
                int w = e->other(v);
                if (e->residualCapacityTo(w) > 0 && !marked[w]) {
                    edgeTo[w] = e;
                    marked[w] = true;
                    st.push(w);
                }
            }
        }
        return marked[t];
    }

    // 计算顶点v的流量过载
    double excess(const FlowNetwork& G, int v) const {
        double excess = 0.0;
        for (const auto& e : G.getAdj(v)) {
            if (v == e->from()) excess -= e->getFlow();
            else excess += e->getFlow();
        }
        return excess;
    }

    // 检查当前流是否可行
    bool isFeasible(const FlowNetwork& G, int s, int t) const {
        for (int v = 0; v < G.getV(); v++) {
            for (const auto& e : G.getAdj(v)) {
                if (e->getFlow() < -FLOATING_POINT_EPSILON || e->getFlow() > e->getCapacity() + FLOATING_POINT_EPSILON) {
                    cerr << "边不满足容量限制: " << e->toString() << endl;
                    return false;
                }
            }
        }

        if (abs(value + excess(G, s)) > FLOATING_POINT_EPSILON) {
            cerr << "源点的过载量 = " << excess(G, s) << endl;
            cerr << "最大流量 = " << value << endl;
            return false;
        }
        if (abs(value - excess(G, t)) > FLOATING_POINT_EPSILON) {
            cerr << "汇点的过载量 = " << excess(G, t) << endl;
            cerr << "最大流量 = " << value << endl;
            return false;
        }

        for (int v = 0; v < G.getV(); v++) {
            if (v == s || v == t) continue;
            else if (abs(excess(G, v)) > FLOATING_POINT_EPSILON) {
                cerr << "顶点 " << v << " 的净流量不等于零" << endl;
                return false;
            }
        }
        return true;
    }

    // 检查最大流的正确性
    bool check(const FlowNetwork& G, int s, int t) const {
        if (!isFeasible(G, s, t)) {
            cerr << "流量不可行" << endl;
            return false;
        }
        if (!inCut(s)) {
            cerr << "源点 " << s << " 不在最小割的源侧" << endl;
            return false;
        }
        if (inCut(t)) {
            cerr << "汇点 " << t << " 在最小割的源侧" << endl;
            return false;
        }

        double mincutValue = 0.0;
        for (int v = 0; v < G.getV(); v++) {
            for (const auto& e : G.getAdj(v)) {
                if ((v == e->from()) && inCut(e->from()) && !inCut(e->to()))
                    mincutValue += e->getCapacity();
            }
        }

        if (abs(mincutValue - value) > FLOATING_POINT_EPSILON) {
            cerr << "最大流量 = " << value << "，最小割值 = " << mincutValue << endl;
            return false;
        }
        return true;
    }

public:
    // 构造函数，计算最大流
    FF(const FlowNetwork& G, int s, int t) : V(G.getV()) {
        if (s < 0 || s >= V) throw invalid_argument("源点索引超出范围");
        if (t < 0 || t >= V) throw invalid_argument("汇点索引超出范围");
        if (s == t) throw invalid_argument("源点等于汇点");

        value = excess(G, t); // 初始流量

        // 不断寻找增广路径，直到没有为止
        while (hasAugmentingPath(G, s, t)) {
            double bottle = numeric_limits<double>::infinity();
            // 找到路径上的最小剩余容量（瓶颈）
            for (int v = t; v != s; v = edgeTo[v]->other(v)) {
                bottle = min(bottle, edgeTo[v]->residualCapacityTo(v));
            }
            // 沿路径推流
            for (int v = t; v != s; v = edgeTo[v]->other(v)) {
                edgeTo[v]->addResidualFlowTo(v, bottle);
            }
            value += bottle;
        }

        // 检查最大流的正确性
        if (!check(G, s, t)) {
            throw runtime_error("最大流计算错误");
        }
    }

    // 获取最大流值
    double getValue() const { return value; }

    // 判断顶点是否在最小割中
    bool inCut(int v) const {
        if (v < 0 || v >= V) throw invalid_argument("顶点索引超出范围");
        return marked[v];
    }
};

// ================== 球队类 ==================
// 用于存储每支球队的基本信息
class Team {
public:
    int wins;      // 胜场数
    int loses;     // 负场数
    int remaining; // 剩余比赛场数
    string explain; // 分析解释

    Team() : wins(0), loses(0), remaining(0), explain(" ") {}
    Team(int wins, int loses, int remaining) : wins(wins), loses(loses), remaining(remaining), explain(" ") {}
};

// ================== 棒球淘汰分析主类 ==================
// 负责读取数据、构建网络、分析淘汰情况
class BaseballElimination {
private:
    int numberOfTeams; // 球队总数
    unordered_map<string, Team> teams; // 球队名称->球队信息
    unordered_map<string, int> teamNameToTeamIndex; // 球队名称->编号
    unordered_map<int, string> teamIndexToTeamName; // 编号->球队名称
    vector<vector<int>> remainingAgainst; // 球队之间剩余比赛场数
    int flow; // 当前分析的总流量

public:
    // 构造函数，读取testdata.txt并初始化所有数据
    BaseballElimination() {
        ifstream file("testdata.txt");
        if (!file.is_open()) {
            throw runtime_error("无法打开testdata.txt文件");
        }

        file >> numberOfTeams;
        remainingAgainst.resize(numberOfTeams, vector<int>(numberOfTeams));

        for (int i = 0; i < numberOfTeams; i++) {
            string name;
            int wins, loses, remaining;
            file >> name >> wins >> loses >> remaining;
            
            teams[name] = Team(wins, loses, remaining);
            teamIndexToTeamName[i] = name;
            teamNameToTeamIndex[name] = i;

            for (int j = 0; j < numberOfTeams; j++) {
                file >> remainingAgainst[i][j];
            }
        }
        file.close();
    }

    // 获取球队总数
    int getNumberOfTeams() const { return numberOfTeams; }

    // 获取所有球队名称
    vector<string> getTeams() const {
        vector<string> teamNames;
        for (const auto& team : teams) {
            teamNames.push_back(team.first);
        }
        return teamNames;
    }

    // 检查球队名称是否合法
    void isValid(const string& team) const {
        if (teams.find(team) == teams.end()) {
            throw invalid_argument("无效的球队名称: " + team);
        }
    }

    // 获取胜场数
    int wins(const string& team) const {
        isValid(team);
        return teams.at(team).wins;
    }

    // 获取负场数
    int losses(const string& team) const {
        isValid(team);
        return teams.at(team).loses;
    }

    // 获取剩余比赛场数
    int remaining(const string& team) const {
        isValid(team);
        return teams.at(team).remaining;
    }

    // 获取两队之间剩余比赛场数
    int against(const string& team1, const string& team2) const {
        isValid(team1);
        isValid(team2);
        int i = teamNameToTeamIndex.at(team1);
        int j = teamNameToTeamIndex.at(team2);
        return remainingAgainst[i][j];
    }

    // 获取球队的分析解释
    string getTeamExplain(const string& team) const {
        isValid(team);
        return teams.at(team).explain;
    }

private:
    // 构建针对某支球队的最大流网络，返回最大流对象
    unique_ptr<FF> getMaxFlow(const string& team) {
        int x = teamNameToTeamIndex[team]; // 被分析球队的编号
        int numberOfGameVertices = numberOfTeams * (numberOfTeams - 1) / 2; // 比赛顶点数
        int numberOfVertices = numberOfGameVertices + numberOfTeams + 2; // 总顶点数
        FlowNetwork flowNetwork(numberOfVertices);
        int s = 0; // 源点
        int t = numberOfVertices - 1; // 汇点
        int index = 1; // 比赛顶点编号起始
        flow = 0;

        // 构建比赛顶点和球队顶点之间的边
        for (int i = 0; i < numberOfTeams; i++) {
            if (i == x) continue;
            for (int j = i + 1; j < numberOfTeams; j++) {
                if (j == x) continue;
                // 源点到比赛顶点，容量为两队剩余比赛数
                flowNetwork.addEdge(make_shared<FlowEdge>(s, index, remainingAgainst[i][j]));
                // 比赛顶点到两支球队顶点，容量为无穷大
                flowNetwork.addEdge(make_shared<FlowEdge>(index, i + numberOfGameVertices + 1, numeric_limits<double>::infinity()));
                flowNetwork.addEdge(make_shared<FlowEdge>(index, j + numberOfGameVertices + 1, numeric_limits<double>::infinity()));
                index++;
                flow += remainingAgainst[i][j];
            }
            // 球队顶点到汇点，容量为w[x]+r[x]-w[i]
            int wX = teams[team].wins;
            int rX = teams[team].remaining;
            int wI = teams[teamIndexToTeamName[i]].wins;
            if (wX + rX - wI < 0) {
                // 剪枝：如果最大可能胜场都比对方少，直接淘汰
                return nullptr;
            } else {
                flowNetwork.addEdge(make_shared<FlowEdge>(i + numberOfGameVertices + 1, t, wX + rX - wI));
            }
        }
        return make_unique<FF>(flowNetwork, s, t);
    }

public:
    // 判断球队是否被淘汰，并记录分析解释
    bool isEliminated(const string& team) {
        isValid(team);
        auto maxFlow = getMaxFlow(team);
        if (maxFlow == nullptr) {
            teams[team].explain = "总剩余比赛流量：" + to_string(flow) + "，最大流：无（已被淘汰）";
            return true;
        } else {
            teams[team].explain = "总剩余比赛流量：" + to_string(flow) + "，最大流：" + to_string(maxFlow->getValue());
            return flow > maxFlow->getValue();
        }
    }

    // 获取导致淘汰的球队集合
    vector<string> certificateOfElimination(const string& team) {
        isValid(team);
        if (!isEliminated(team)) {
            return {};
        }

        vector<string> list;
        int x = teamNameToTeamIndex[team];
        int numberOfGameVertices = numberOfTeams * (numberOfTeams - 1) / 2;
        auto maxFlow = getMaxFlow(team);

        for (int index = 0; index < numberOfTeams; index++) {
            if (index == x) continue;
            if (maxFlow == nullptr) {
                int wX = teams[team].wins;
                int rX = teams[team].remaining;
                int wI = teams[teamIndexToTeamName[index]].wins;
                if (wX + rX - wI < 0) {
                    cout << "  原因：" << team << " 被 " << teamIndexToTeamName[index] << " 淘汰。" <<
                            " 计算依据：胜场 w[x]=" << wX << "，剩余场次 r[x]=" << rX << "，" <<
                            "对方胜场 w[i]=" << wI << "，结果 w[x] + r[x] - w[i] = " << (wX + rX - wI) << endl;
                    list.push_back(teamIndexToTeamName[index]);
                }
            } else if (maxFlow->inCut(index + numberOfGameVertices + 1)) {
                cout << "  原因：" << teamIndexToTeamName[index] << " 在最小割的源点一侧，对应淘汰子集。" << endl;
                list.push_back(teamIndexToTeamName[index]);
            }
        }
        return list;
    }
};

// ================== 主程序入口 ==================
int main() {
    try {
        auto startTime = chrono::high_resolution_clock::now(); // 记录开始时间

        BaseballElimination division; // 创建分析对象
        
        // 遍历所有球队，输出淘汰分析
        for (const string& team : division.getTeams()) {
            if (division.isEliminated(team)) {
                cout << team << "：被淘汰" << endl;
                cout << "  当前状态分析：" << division.getTeamExplain(team) << endl;
                
                vector<string> eliminationSet = division.certificateOfElimination(team);
                if (!eliminationSet.empty()) {
                    cout << "  导致该队淘汰的球队集合：{ ";
                    for (size_t i = 0; i < eliminationSet.size(); i++) {
                        if (i > 0) cout << ", ";
                        cout << eliminationSet[i];
                    }
                    cout << " }" << endl;
                }
                cout << endl;
            }
        }

        auto endTime = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::milliseconds>(endTime - startTime);
        cout << "程序运行时间: " << duration.count() << " 毫秒" << endl;

    } catch (const exception& e) {
        cerr << "错误: " << e.what() << endl;
        return 1;
    }

    return 0;
} 